<div class="row-fluid" style="background-color: #fff;">
	<div class="span5" style="padding: 25px 0px 25px 80px;">
		<a href="<?php echo DOMAIN; ?>"><img src="/img/smpl1.jpg" width="100px"></img></a>	
	</div>
	<div class="span7" style="padding: 33px 80px 23px 140px;">
		<ul id="navigation">
			<li id="menu1" style="padding: 2px 2px 2px 2px;"><a href="<?php echo DOMAIN;?>/index.php"><span>Projects</span></a></li>
			<li id="menu2" style="padding: 2px 2px 2px 2px;"><a href="<?php echo DOMAIN;?>/training.php"><span>Training</span></a></li>
			<li id="menu3" style="padding: 2px 2px 2px 2px;"><a href="<?php echo DOMAIN;?>/includes/contact_us.php"><span>contact</span></a></li>
			<li style="padding: 2px 2px 2px 2px;"><a href="#"><span><i class="fa fa-facebook-square" style="font-size: 2em;"></i></span></a>&nbsp;&nbsp;&nbsp;<a href="#"><span><i class="fa fa-twitter" style="font-size: 2em;"></i></span></a></li>
		</ul>
	</div>
</div>