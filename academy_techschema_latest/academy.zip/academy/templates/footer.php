<div class="row-fluid">
	<div style="color: #fff; margin-top: 50px" id="bottom">
		<div class="span2">
		</div>
		<div class="span2">
			<ul>
				<li style="font-size: 1em; font-weight: bold;">get to know us</li>
				<li>read our blog</li>
				<li>facebook</li>
				<li>twitter</li>
			</ul>
		</div>
		<div class="span2">
			<ul>
				<li style="font-size: 1em; font-weight: bold;">connect</li>
				<a href="<?php echo DOMAIN;?>/includes/contact_us.php"><li>contact info</li></a>
			</ul>	
		</div>
		<div class="span2">
			<ul>
				<li style="font-size: 1em; font-weight: bold;">get involved</li>
				<li>Diploma</li>
				<li>B.E.</li>
				<li>M.E.</li>
				<li>B.Sc. IT</li>
				<li>B.Sc. Comp Sci.</li>
				<li>Ph.D.</li>
				<li>PHP</li>
				<li>Ruby on Rails</li>
			</ul>
		</div>
		<div class="span2">
			<ul>
				<li style="font-size: 1em; font-weight: bold;">about us</li>
			</ul>
		</div>
		<div class="span2">
		</div>
	</div>
	<div class="row-fluid">
		<div class="offset1 span10 offset1" style="margin-top: 20px; margin-bottom: 20px; text-align: center">
			<p style="border: 1px solid"></p>
			<p><a style="color: #fff; font-family: Raleway; font-size: 1em;">Powered by Tech Schema</a></p>
		</div>
	</div>
</div>